/*
 * funciones.h
 *
 *  Created on: 12 oct 2023
 *      Author: aleco
 */

#ifndef SRC_FUNCIONES_H_
#define SRC_FUNCIONES_H_

#include <iostream>
#include <GL\glut.h>
using namespace std;
void Inicializar();
void Triangulo();
void traslado(int,int,int);
void Dibujar();


#endif /* SRC_FUNCIONES_H_ */
