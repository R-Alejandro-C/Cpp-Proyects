/*
 * inicio.cpp
 *
 *  Created on: 12 oct 2023
 *      Author: aleco
 */



#include "funciones.h"
float mover_x=0;
float mover_y=0;
void Inicializar(){
	glClearColor(0.5, 0.0, 0.5, 1.0);

glMatrixMode(GL_PROJECTION);
glLoadIdentity();
glOrtho(-16.0,16.0,-16.0,16.0,-16.0,16.0);
}
void planoCarteciano (){

glBegin(GL_LINES);
glVertex2f(-10.0,0.0);
glVertex2f(10.0,0.0);
glEnd();
glBegin(GL_LINES);
glVertex2f(0.0,-10.0);
glVertex2f(0.0,10.0);
glEnd();

}


void Dibujar(){
glClear(GL_COLOR_BUFFER_BIT);
glPushMatrix();
planoCarteciano();
glTranslatef(mover_x,mover_y,0.0);
Triangulo();
glPushMatrix();
glPopMatrix();
glFlush();
}
void traslado(int key, int x, int y){
switch(key)
{
case GLUT_KEY_RIGHT: mover_x++;break;
case GLUT_KEY_LEFT: mover_x--;break;
case GLUT_KEY_UP: mover_y++; break;
case GLUT_KEY_DOWN: mover_y--;break;
}
glutPostRedisplay();
}
